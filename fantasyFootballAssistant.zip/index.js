
//https://fantasy.espn.com/apis/v3/games/ffl/seasons/2021/segments/0/leagues/72628823?view=mMatchup&view=mMatchupScore&scoringPeriodId=1
//https://fantasy.espn.com/apis/v3/games/ffl/seasons/2021/segments/0/leagues/72628823?view=mMatchup&view=mMatchupScore&scoringPeriodId=1
//Access Key ID:
//AKIA2NPEPNBWNBGUZGN4
//Secret Access Key:
//RB2RW5ZMCv10tLY3i8XOlNaqNBb7cv0NDMdIjOqO
/*
https://email.us-west-2.amazonaws.com/
?Action=SendEmail
&Source=ian.cornish1%40gmail.com
&Destination.ToAddresses.member.1=ian.cornish1%40gmail.com
&Message.Subject.Data=Week%201%20Injury%20Report
&Message.Body.Text.Data=%3C%21DOCTYPE%20html%3E%20%3Chtml%3E%3Cstyle%3E%20.out%20%7Bcolor%3Ared%3B%20font-weight%3A%20bold%3B%7D%20%20.doubt%20%7Bcolor%3Aorange%3B%20font-weight%3A%20bold%3B%7D%20%23players%20%7B%20font-family%3A%20Arial%2C%20Helvetica%2C%20sans-serif%3B%20border-collapse%3A%20collapse%3B%7D%20%23players%20td%2C%20%23players%20th%20%7B%20border%3A%201px%20%7D%20%23header%20%7Btext-align%3A%20center%3Bbackground-color%3A%20%2304AA6D%3Bcolor%3A%20white%3B%7D%3C%2Fstyle%3E%20%3Cbody%3E%20%3Ctable%20id%3D%22players%22%3E%20%3Ctr%3E%20%3Ctd%20id%3D%22header%22%20colspan%20%3D%20%223%22%3E%3Cb%3EWeek%20%201%20Injury%20Report%3C%2Fb%3E%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%20style%3D%22background-color%3A%20%23ddd%20%21important%22%3E%20%3Ctd%20colspan%20%3D%20%225%22%3E%20%3Cb%3EChris%20Serrano%3C%2Fb%3E%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%3E%20%3Ctd%3E%20Josh%20Jacobs%20%3C%2Ftd%3E%20%3Ctd%3E%20QUESTIONABLE%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%20style%3D%22background-color%3A%20%23ddd%20%21important%22%3E%20%3Ctd%20colspan%20%3D%20%225%22%3E%20%3Cb%3ECody%20Ponce%3C%2Fb%3E%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%3E%20%3Ctd%3E%20Saquon%20Barkley%20%3C%2Ftd%3E%20%3Ctd%3E%20QUESTIONABLE%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%20style%3D%22background-color%3A%20%23ddd%20%21important%22%3E%20%3Ctd%20colspan%20%3D%20%225%22%3E%20%3Cb%3EJosh%20Hinrichsen%3C%2Fb%3E%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%3E%20%3Ctd%3E%20Austin%20Ekeler%20%3C%2Ftd%3E%20%3Ctd%3E%20QUESTIONABLE%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%20style%3D%22background-color%3A%20%23ddd%20%21important%22%3E%20%3Ctd%20colspan%20%3D%20%225%22%3E%20%3Cb%3ERichard%20Stubing%3C%2Fb%3E%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%3Ctr%3E%20%3Ctd%3E%20Noah%20Fant%20%3C%2Ftd%3E%20%3Ctd%3E%20QUESTIONABLE%20%3C%2Ftd%3E%20%3C%2Ftr%3E%20%20%3C%2Ftable%3E%20%3C%2Fbody%3E%20%3C%2Fhtml%3E
&AWSAccessKeyId=AKIA2NPEPNBWNBGUZGN4,Algorithm=HMACSHA256,Signature=lBP67vCvGl


Region:us-east-2	

*/

var dateStamp = new Date();
var dd = String(dateStamp.getDate()).padStart(2, '0');
var mm = String(dateStamp.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = dateStamp.getFullYear();
dateStamp=yyyy+mm+dd;

const awsRegion = 'us-east-2';

console.log(dateStamp);
var axios = require('axios');
let fs = require('fs');
//import {groupBy} from './appHelper.mjs';

function groupBy(list, keyGetter) {
    const map = new Map();
    list.forEach((item) => {
         const key = keyGetter(item);
         const collection = map.get(key);
         if (!collection) {
             map.set(key, [item]);
         } else {
             collection.push(item);
         }
    });
    return map;
}

exports.handler = function(){

let week =1;

let reportName = 'week'+ week + 'injuryReport.html';
let urlBase ='https://fantasy.espn.com/apis/v3/games/ffl/seasons/2021/segments/0/leagues/72628823?view=mMatchup&view=mMatchupScore&scoringPeriodId=';
let url = urlBase.concat(week);

const teamIdByOwner = [{teamId : "1", teamOwner : "Ian Cornish"},
                       {teamId : "2", teamOwner : "Richard Stubing"},
                       {teamId : "3", teamOwner : "Donnie Reynolds"},
                       {teamId : "4", teamOwner : "Devlin Brooks"},
                       {teamId : "5", teamOwner : "Freddy Ponce"},
                       {teamId : "6", teamOwner : "Kyle Hurley"},
                       {teamId : "7", teamOwner : "Austin Reeves"},
                       {teamId : "8", teamOwner : "Danny Stubing"},
                       {teamId : "9", teamOwner : "Chris Serrano"},
                       {teamId : "10", teamOwner : "Josh Hinrichsen"},
                       {teamId : "11", teamOwner : "David Goodyear"},
                       {teamId : "12", teamOwner : "Cody Ponce"}];

const lineupSlotIdByPositionName = [{lineupSlotId : "0", positionName : "Quarterback"},
                                    {lineupSlotId : "2", positionName : "Running Back"},
                                    {lineupSlotId : "4", positionName : "Wide Reciever"},
                                    {lineupSlotId : "6", positionName : "Tight End"},
                                    {lineupSlotId : "16", positionName : "D/ST"},
                                    {lineupSlotId : "17", positionName : "Kicker"},
                                    {lineupSlotId : "20", positionName : "Bench"},
                                    {lineupSlotId : "23", positionName : "Flex"}];

async function compileHtmlOutput(){ return axios.get(url).then(async (res)=> 
{   
    let responseTeams = res.data.teams;
    
        let teamRosters = [];
        for(let i of responseTeams){
            teamRosters.push(i.roster);
        }
        let listOfRosterEntries = [];
        for(let j of teamRosters){
            for(let l = 0; l< j.entries.length; l++){
                listOfRosterEntries.push(j.entries[l]);
            }
        }
        const playersOnFantasyRosters = listOfRosterEntries.map(entry => {

            let ownerNameValue = teamIdByOwner.filter(team => team.teamId == entry.playerPoolEntry.onTeamId);
            let positionNameValue = lineupSlotIdByPositionName.filter(position => position.lineupSlotId == entry.lineupSlotId);

            return{playerFullName : entry.playerPoolEntry.player.fullName,
                   ownerName : ownerNameValue[0].teamOwner,
                   injuryStatus : entry.playerPoolEntry.player.injuryStatus,
                   position : positionNameValue[0].positionName,
                   playerId : entry.playerId,
                   currentLineupSlotId : entry.lineupSlotId,
                   teamId : entry.playerPoolEntry.onTeamId
                   };
        });

        const getOutStartingPlayers = playersOnFantasyRosters.filter(player => player.position != "Bench" && player.position != "D/ST" && player.injuryStatus != "ACTIVE" && player.injuryStatus != "QUESTIONABLE");
        const getInactiveStartingPlayers = playersOnFantasyRosters.filter(player => player.position != "Bench" && player.position != "D/ST" && player.injuryStatus != "ACTIVE");
        const getQuestionableStartingPlayers = playersOnFantasyRosters.filter(player => player.position != "Bench" && player.position != "D/ST" && player.injuryStatus == "QUESTIONABLE");
        
        const startingPlayersWithStatusByOwner = new Map([...groupBy(getInactiveStartingPlayers, player => player.ownerName).entries()].sort()); 
        var htmlOutput = '<!DOCTYPE html> <html><style> .out {color:red; font-weight: bold;}  .doubt {color:orange; font-weight: bold;} #players { font-family: Arial, Helvetica, sans-serif; border-collapse: collapse;} #players td, #players th { border: 1px } #header {text-align: center;background-color: #04AA6D;color: white;}</style> <body> <table id="players"> <tr> <td id="header" colspan = "3"><b>Week  ' + week + ' Injury Report</b></td> </tr> ';

        for(let [key, value] of startingPlayersWithStatusByOwner){
            htmlOutput = htmlOutput.concat('<tr style="background-color: #ddd !important"> <td colspan = "5"> <b>' +key+ '</b> </td> </tr>')
            for(const player of startingPlayersWithStatusByOwner.get(key)){
                htmlOutput= htmlOutput.concat(' <tr> ');
                if(player.injuryStatus=='OUT' || player.injuryStatus=='INJURY_RESERVE'){
                    htmlOutput = htmlOutput.concat('<td class="out"> ' + player.playerFullName + ' </td> <td class="out"> ' + player.injuryStatus +' </td>');
                }else if(player.injuryStatus=='DOUBTFUL'){
                    console.log(player.playerFullName);
                    htmlOutput = htmlOutput.concat('<td class="doubt"> ' + player.playerFullName + ' </td> <td class="doubt"> ' + player.injuryStatus +' </td>');
                }else{
                    htmlOutput = htmlOutput.concat('<td> ' + player.playerFullName + ' </td> <td> ' + player.injuryStatus +' </td>');
                }
                htmlOutput= htmlOutput.concat(' </tr> ');
            }
        }
        htmlOutput = htmlOutput.concat(' </table> </body> </html>');
        fs.writeFile(reportName, htmlOutput, function(err){
            if(err != null){
            console.log('Error: ' + err);
            }
        })
return htmlOutput;}    
);
    };
let injuryReport = compileHtmlOutput().then(async (htmlOutput)=>{
    return htmlOutput;
});
return injuryReport;
};
